<img align="right" width="64" height="64" src="./assets/logo.png">

## JutSu
Тул для скачивания вашего любимого аниме с jut.su

----

### Скриншоты
![ss1](./assets/1.png)
![ss2](./assets/2.png)
![ss3](./assets/3.png)
![ss4](./assets/4.png)



